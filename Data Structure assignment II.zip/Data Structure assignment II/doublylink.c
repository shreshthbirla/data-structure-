#include<stdio.h>
#include<stdlib.h>

struct node
{
int data;
struct node *left;
struct node *right;
};

void display(struct node*);
struct node* insert_front(struct node*,int);
struct node* delete(struct node*);

int main()
{
struct node *first = (struct node*)malloc(sizeof(struct node));
struct node *second = (struct node*)malloc(sizeof(struct node));
struct node *third = (struct node*)malloc(sizeof(struct node));
struct node *fourth = (struct node*)malloc(sizeof(struct node));


first->data = 100;
first->left = NULL;
first->right = second;

second->data = 200;
second->left = first;
second->right = third;

third->data = 300;
third->left = second;
third->right = fourth;

fourth->data = 400;
fourth->left = third;
fourth->right = NULL;


printf("before inserting: ");
display(first);

printf("\nafter inserting: ");
first = insert_front(first,50);
display(first);


printf("\nafter delete: ");
first = delete(first);
display(first);
}

void display(struct node *first)
{
struct node *ptr;
ptr = first;

while(ptr!=NULL)
{
printf("%d, ",ptr->data);
ptr=ptr->right;
}
}



struct node* insert_front(struct node *first,int data)
{
struct node *ptr = (struct node*)malloc(sizeof(struct node));
ptr->data = data;
ptr->left = NULL;
ptr->right = NULL;


ptr->right = first;
first->left = ptr;
first = ptr;
return first;
}

struct node* delete(struct node *first)
{
struct node *temp, *p;
temp = first;
while(temp->right!=NULL)
{
temp = temp->right;
}
p=temp->left;
p->right=NULL;
free(temp);
return first;
}






















