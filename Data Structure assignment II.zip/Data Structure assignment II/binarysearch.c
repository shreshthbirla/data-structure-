#include<stdio.h>
#include<stdlib.h>

struct node{
char data;
struct node *left;
struct node *right;
}*root = NULL, *temp = NULL, *t2, *t1;;

void insert();
void delete1();

void search(struct node *t);
void inorder(struct node *t);
void create();
void delete();
void search1(struct node *t,int data);
int smallest(struct node *t);
int largest(struct node *t);

void delete1();

int flag=1;

void main()
{
int n;

printf("\n1.Insert an element into tree\n2.Delete an element from the tree\n3.Inorder Traversal\n4.Exit\n");

while(1)
{
printf("\nEnter your choice : ");
scanf("%d", &n);
switch (n)
{
case 1:    
insert();
break;

case 2:    
delete();
break;

case 3:    
inorder(root);
break;

case 4:    
exit(0);
default :     

printf("Wrong choice, Please enter correct choice  ");
break;    
}
}
}


void inorder(struct node *t)
{
if (root == NULL)
{
printf("No elements in a tree to display");
return;
}
if (t->left != NULL)    
inorder(t->left);
printf("%d, ", t->data);
if (t->right != NULL)    
inorder(t->right);
}

void insert()
{
create();
if (root == NULL) 
root = temp;
else    
search(root);    
}


void create()

{
int data;
printf("Enter data of node to be inserted : ");
scanf("%d", &data);
temp = (struct node *)malloc(sizeof(struct node));
temp->data = data;
temp->left = temp->right = NULL;
}

void search(struct node *t)

{
if ((temp->data > t->data) && (t->right != NULL))      
search(t->right);
else if ((temp->data > t->data) && (t->right == NULL))
t->right = temp;
else if ((temp->data < t->data) && (t->left != NULL))   
search(t->left);
else if ((temp->data < t->data) && (t->left == NULL))
t->left = temp;
}

void delete()
{
int data;
if (root == NULL)
{
printf("No elements in a tree to delete");
return;
}
printf("Enter the data to be deleted : ");
scanf("%d", &data);
t1 = root;
t2 = root;
search1(root, data);
}


void search1(struct node *t, int data)
{
if ((data>t->data))
{
t1 = t;
search1(t->right, data);
}
else if ((data < t->data))
{
t1 = t;
search1(t->left, data);
}
else if ((data==t->data))
{
delete1(t);
}
}

void delete1(struct node *t)
{
int k;
if ((t->left == NULL) && (t->right == NULL))
{
if (t1->left == t)
{
t1->left = NULL;
}
else
{
t1->right = NULL;
}
t = NULL;
free(t);
return;
}
else if ((t->right == NULL))
{
if (t1 == t)
{
root = t->left;
t1 = root;
}
else if (t1->left == t)
{
t1->left = t->left;
}
else
{
t1->right = t->left;
}
t = NULL;
free(t);
return;
}

else if (t->left == NULL)
{
if (t1 == t)
{
root = t->right;
t1 = root;
}
else if (t1->right == t)
t1->right = t->right;
else
t1->left = t->right;
t == NULL;
free(t);
return;
}
else if ((t->left != NULL) && (t->right != NULL))  
{
t2 = root;
if (t->right != NULL)
{
k = smallest(t->right);
flag = 1;
}
else
{
k =largest(t->left);
flag = 2;
}
search1(root, k);
t->data = k;
}
}

int smallest(struct node *t)

{
t2 = t;
if (t->left != NULL)
{
t2 = t;
return(smallest(t->left));
}
else    
return (t->data);
}

int largest(struct node *t)
{
if (t->right != NULL)
{
t2 = t;
return(largest(t->right));
}
else    
return(t->data);

}
