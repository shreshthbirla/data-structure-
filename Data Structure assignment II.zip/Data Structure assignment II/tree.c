#include<stdio.h>
#include<stdlib.h>

struct node
{
char data;
struct node *left;
struct node *right;
};

int preorder(struct node *);
int postorder(struct node *);
int inorder(struct node *);

void main()
{
struct node *a,*b,*c,*d,*e,*f,*g,*root;
a=(struct node *)malloc(sizeof(struct node));
b=(struct node *)malloc(sizeof(struct node));
c=(struct node *)malloc(sizeof(struct node));
d=(struct node *)malloc(sizeof(struct node));
e=(struct node *)malloc(sizeof(struct node));
f=(struct node *)malloc(sizeof(struct node));
g=(struct node *)malloc(sizeof(struct node));

root=a;
a->data='1';
a->left=b;
a->right=d;

b->data='3';
b->left=c;
b->right=NULL;

c->data='2';
c->left=NULL;
c->right=NULL;

d->data='5';
d->left=e;
d->right=g;

e->data='6';
e->left=NULL;
e->right=f;

f->data='8';
f->left=NULL;
f->right=NULL;

g->data='7';
g->left=NULL;
g->right=NULL;

printf("\npreorder of tree: ");
preorder(root);
printf("\npostorder of tree: ");
postorder(root);
printf("\ninorder of tree: ");
inorder(root);

}

int preorder(struct node *root)
{
if(root==NULL)
{
printf("tree is null");
}
else
{
printf("%c ",root->data);
if(root->left!=NULL)
{
preorder(root->left);
}
if(root->right!=NULL)
{
preorder(root->right);
}
}
}

int postorder(struct node *root)
{
if(root==NULL)
{
printf(" tree empty");
}
else
{
if(root->left!=NULL)
{
postorder(root->left);
}
if(root->right!=NULL)
{
postorder(root->right);
}
}
printf("%c ",root->data);
}


int inorder(struct node *root)
{
if(root==NULL)
{
printf("tree is empty");
}
else
{
if(root->left!=NULL)
{
inorder(root->left);
}
printf("%c ",root->data);
if(root->right!=NULL)
{
inorder(root->right);
}
}
}














