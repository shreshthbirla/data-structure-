#include<stdio.h>
#include<stdlib.h>

struct node{
int info;
struct node *link;
};

void display(struct node*);
void count(struct node*);
struct node* insert(int,struct node*);
struct node* insend(int,struct node*);
struct node* insert_inbetween(struct node *, int , int);
struct node* delete(int,struct node*);
struct node* copy(struct node *);

void main()
{
int o;
struct node *first, *second, *third;
first=(struct node*)malloc(sizeof(struct node));
second=(struct node*)malloc(sizeof(struct node));
third=(struct node*)malloc(sizeof(struct node));
first->info=1;
first->link=second;

second->info=2;
second->link=third;

third->info=3;
third->link=NULL;

printf("Linked list before insertion\n");
    display(first);

while(o<7)
{
printf("\nenter operation you want to perform\n");
printf("1.insert at front\n2.insert at end\n3.insort\n4.delete\n5.count\n6.copy\n7.quit\n");
scanf("%d",&o);

switch(o)

{ 
  case 1:
   first = insert(25,first);
   printf("Linked list after insertion\n");
   display(first);
   break;

  case 2:
   first = insend(45,first);
   printf("Linked list after insertion\n");
   display(first);
   break;
 
  case 3:
    first = insert_inbetween(first, 56, 1);
    printf("Linked list after insertion\n");
    display(first);
    break;

  case 4:
    first = delete(2,first);
    printf("Linked list after delete\n");
    display(first);
    break;
  
  case 5:
  count(first);

  case 6:
  printf("copied list is: ");
  copy(first);
  display(first);
  break;
}
}
}


void display(struct node *ptr)
{
while (ptr != NULL)
{
printf("%d, ", ptr->info);
ptr = ptr->link;
}
}

struct node* insert(int x,struct node *first)
{
struct node *new;
new=(struct node*)malloc(sizeof(struct node));
if(new==NULL)
{
printf("overflow");
return(first);
}
else
{
new->info=x;
if(first==NULL)
{
new->link=NULL;
return new;
}
else
{
new->link=first;
return new;
}
}
}

struct node* insend(int info,struct node *first)
{
struct node * ptr = (struct node *) malloc(sizeof(struct node));
ptr->info = info;
struct node * p = first;

while(p->link!=NULL)
{
p = p->link;
}
p->link = ptr;
ptr->link = NULL;
return first;
}

struct node* insert_inbetween(struct node *first, int info, int index)
{
struct node * ptr = (struct node *) malloc(sizeof(struct node));
struct node * p = first;
int i = 0;

while (i!=index-1)
{
p = p->link;
i++;
}
ptr->info = info;
ptr->link = p->link;
p->link = ptr;
return (first);
}

struct node *delete(int index,struct node * first)
{
struct node *p = first;
struct node *q = first->link;
for (int i = 0; i < index-1; i++)
{
p = p->link;
q = q->link;
}
p->link = q->link;
free(q);
return (first);
}

void count(struct node *first)  
{
int count =0;
if(first==NULL)
{
printf("linked list is empty");
}
else
{
struct node *ptr=NULL;
ptr=first;
while(ptr!=NULL)
{
count++;
ptr=ptr->link;
}
printf("\ntotal number of nodes is : %d\n",count);
}
}

struct node* copy(struct node *first)
{
if(first==NULL)
{
return NULL;
}
else
{
struct node * new = (struct node *)malloc (sizeof(struct node));
new->info = first->info;
new->link = copy(first->link);
return new;
}
}















